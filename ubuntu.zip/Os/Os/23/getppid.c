#include<stdio.h>
#include<sys/types.h>
#include<unistd.h>
int main()
{
             int pid;
             pid = getpid();
             printf("current process ID is :%d\n",pid);
             printf("\n [Forking childprocess....]\n");
             pid=fork();
             if(pid<0)
             {
                  printf("\nProcess can not be created");
                  }
                  else
                  {
                     if(pid==0)
                     {
                                printf("\n0rphan child's parent ID: %d",getpid());
                                }
                                else
                                {
                                printf("\n Parent process completed..");
                                }
                          
                   return 0;
                   }
}

